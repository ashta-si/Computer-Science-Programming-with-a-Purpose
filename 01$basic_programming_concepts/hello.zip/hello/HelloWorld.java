/*
Name          : Gobal Krishnan V
Date of Birth : 18/06/1995
Compilation   : javac HelloWorld
Execution     : java HelloWorld

%java HelloWorld
Hello, World
*/

public class HelloWorld{

    public static void main(String[] args){
        System.out.println("Hello, World");
    }
}